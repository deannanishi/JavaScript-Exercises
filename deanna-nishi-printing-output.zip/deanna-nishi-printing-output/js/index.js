// Assign variable experiment with concatenated expression.
		
// Print experiment using alert()
// Print experiment using console.log()

// Declare three variables, a and b and c.

/*
TASK 1 
If a has value 3, b has value 5, and c doesn't have a value, alert the following expressions ( one after another ). Alert popup box has to show the following content for each expression (concatenate everything in one long expression using "\n" to make new lines):

 
*/

let a = 3;
let b = 5;
let c;

let printing_output = `let a = 3;\nlet b = 5;\nlet c;\n------\na + b = ${a + b}\na - b = ${a - b}\na * b = ${a * b}\na / b = ${a / b}\na + b = ${a % b}\na + b = ${a += b}\na + b = ${a -= b}\na + b = ${a *= b}\na + b = ${a /= b}\na + b = ${a %= b}\na + b = ${a == b}\na + b = ${a != b}\na + b = ${a > b}\na + b = ${a < b}\na + b = ${!a && !c}\na + b = ${!a || !c}`;

alert(printing_output);

//TASK 2

let first_name = "Deanna";
let last_name = "Nishi";
let email = "nish0018@algonquinlive.com";
let output = `My name is ${first_name} ${last_name}. You can contact me at ${email}`;

console.log(output);
